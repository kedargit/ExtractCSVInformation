﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtractStdZVersionFromCsvFiles.DataModels
{

    public class StandardVersionCollectionBuilder
    {
        List<StandardVersion> standardVersions;
        public List<StandardVersion> BuildVersionCollection(int noOfVersions)
        {
            standardVersions = new List<StandardVersion>();
            for (int counter = 0; counter < noOfVersions; counter++)
            {
                StandardVersion version = new StandardVersion()
                {
                    standardPartDInfo = new StandardPartDInfo(),
                    standardPartEInfo = new StandardPartEInfo(),
                };
                standardVersions.Add(version);
            }
            return standardVersions;
        }

        public List<StandardVersion> UpdateVersionInfo(List<StandardVersion> standardVersions, VersionIdRow dataRow)
        {
            int counter = 0;
            foreach (var version in standardVersions)
            {
                version.VersionId = dataRow.values[counter];
                counter++;
            }

            return standardVersions;
        }

        public List<StandardVersion> UpdatePartDVersionInfo(List<StandardVersion> standardVersions, CsvDataRow dataRow)
        {
            int counter = 0;
            foreach (var version in standardVersions)
            {
                if (version.standardPartDInfo.standardEntrySortationCounts == null)
                    version.standardPartDInfo.standardEntrySortationCounts = new List<StandardEntrySortationCounts>();

                version.standardPartDInfo
                .standardEntrySortationCounts.Add(
                                    new StandardEntrySortationCounts()
                                    {
                                        destinationEntry = dataRow.destinationEntry,
                                        sortation = dataRow.sortation,
                                        Copies = dataRow.Copies[counter]
                                    }
                                    );
                counter++;
            }

            return standardVersions;
        }

        public List<StandardVersion> UpdatePartEVersionInfo(List<StandardVersion> standardVersions, CsvDataRow dataRow)
        {
            int counter = 0;
            foreach (var version in standardVersions)
            {
                if (version.standardPartEInfo.standardEntrySortationCounts == null)
                    version.standardPartEInfo.standardEntrySortationCounts = new List<StandardEntrySortationCounts>();

                version.standardPartEInfo
                .standardEntrySortationCounts.Add(
                                    new StandardEntrySortationCounts()
                                    {
                                        destinationEntry = dataRow.destinationEntry,
                                        sortation = dataRow.sortation,
                                        Copies = dataRow.Copies[counter]
                                    }
                                    );
                counter++;
            }

            return standardVersions;
        }


        public List<StandardVersion> UpdatePieceWtVersionInfo(List<StandardVersion> standardVersions, PieceWeightRow dataRow)
        {
            int counter = 0;
            foreach (var version in standardVersions)
            {
                if (dataRow.pieceWeight == PieceWeight.PieceWeightInOz)
                    version.PieceWtInOz = dataRow.values[counter];
                if (dataRow.pieceWeight == PieceWeight.PieceWeightInPounds)
                    version.PieceWtInPounds = dataRow.values[counter];

                counter++;
            }

            return standardVersions;
        }
    }
    public class StandardVersion
    {
        public string VersionId;
        public decimal PieceWtInPounds;
        public decimal PieceWtInOz;
        public StandardPartDInfo standardPartDInfo;
        public StandardPartEInfo standardPartEInfo;

        public StandardVersion()
        {
            standardPartDInfo = new StandardPartDInfo();
            standardPartEInfo = new StandardPartEInfo();
        }
    }

    public class StandardPartDInfo
    {
        public List<StandardEntrySortationCounts> standardEntrySortationCounts;
    }

    public class StandardPartEInfo
    {
        public List<StandardEntrySortationCounts> standardEntrySortationCounts;
    }

    public class StandardEntrySortationCounts
    {
        public DestinationEntry destinationEntry;
        public Sortation sortation;
        public long Copies;
    }

    public enum DestinationEntry
    {
        [Description("Origin")]
        Origin,
        [Description("NDC")]
        Ndc,
        [Description("SCF")]
        Scf
    }

    public enum Sortation
    {
        [Description("5 Digit")]
        FiveDigit,
        [Description("3 Digit")]
        ThreeDigit,
        [Description("ADC")]
        Adc,
        [Description("MADC")]
        MADC
    }

    public enum PieceWeight
    {
        [Description("PIECE WEIGHT(OZ)")]
        PieceWeightInOz,
        [Description("PIECE WEIGHT(LBS)")]
        PieceWeightInPounds,
    }

    public class CsvDataRow
    {
        public DestinationEntry destinationEntry;
        public Sortation sortation;
        public List<long> Copies;
    }

    public class PieceWeightRow
    {
        public PieceWeight pieceWeight;
        public List<decimal> values;
    }

    public class VersionIdRow
    {
        public List<string> values;
    }

}
