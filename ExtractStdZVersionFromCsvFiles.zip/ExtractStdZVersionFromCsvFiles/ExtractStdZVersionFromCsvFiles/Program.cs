﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.XPath;
using CsvHelper;
using ExtractStdZVersionFromCsvFiles.DataModels;


namespace ExtractStdZVersionFromCsvFiles
{
    class Program
    {
        static void Main(string[] args)
        {
            FileReader reader = new FileReader(@"../../Data Files/FE2_LynFebC_MegaSummary_Bolingbrook_Line_03.csv");
            reader.Read();
        }
    }

    public class FileReader
    {
        public string Path { get; set; }
        public FileReader(string path)
        {
            this.Path = path;
        }

        public void Read()
        {
            CsvParser parser;
            using (TextReader textReader = File.OpenText(Path))
            {
                parser = new CsvParser(textReader);
                parser.Configuration.Delimiter = ",";

                // read line by line
                string[] row = null;
                int lineNumber = 1;
                StandardVersionCollectionBuilder builder = new StandardVersionCollectionBuilder();
                List<StandardVersion> standardVersions = null;
                do
                {
                    row = parser.Read();
                    standardVersions = ProcessSingleRow(row, lineNumber, builder, standardVersions);
                    lineNumber++;

                } while (row != null);
            }

        }

        private List<StandardVersion> ProcessSingleRow(string[] row, int lineNumber, StandardVersionCollectionBuilder builder, List<StandardVersion> standardVersions)
        {
            // version info
            standardVersions = ProcessStandardVersionInfo(row, lineNumber, builder, standardVersions);

            // pieceWeight info
            standardVersions = ProcessStandardPieceWtInfo(row, lineNumber, builder, standardVersions);

            // Part D info
            standardVersions = ProcessStandardPartDInfo(row, lineNumber, builder, standardVersions);

            //Part E
            standardVersions = ProcessStandardPartEInfo(row, lineNumber, builder, standardVersions);
            return standardVersions;
        }

        private List<StandardVersion> ProcessStandardVersionInfo(string[] row, int lineNumber,
           StandardVersionCollectionBuilder builder, List<StandardVersion> standardVersions)
        {
            if (CheckDataRowExists("VersionNames", lineNumber))
            {
                VersionIdRow dataRowWithValues = GetCsvVersionRowDataValue(new VersionIdRow(), row);
                // then get the values and build the data model 

                // step 1 : get the no of versions
                int noOfVersions = row.Count() - 3;
                if (standardVersions == null)
                    standardVersions = builder.BuildVersionCollection(noOfVersions);
                standardVersions = builder.UpdateVersionInfo(standardVersions, dataRowWithValues);
            }

            return standardVersions;
        }

        private List<StandardVersion> ProcessStandardPieceWtInfo(string[] row, int lineNumber,
            StandardVersionCollectionBuilder builder, List<StandardVersion> standardVersions)
        {
            if (CheckDataRowExists("PieceWeightInfos", lineNumber))
            {
                PieceWeightRow dataRow = GetPieceWeightSetting(lineNumber);
                PieceWeightRow dataRowWithValues = GetCsvRowDataValue(dataRow, row);
                // then get the values and build the data model 

                // step 1 : get the no of versions
                int noOfVersions = row.Count() - 3;
                if (standardVersions == null)
                    standardVersions = builder.BuildVersionCollection(noOfVersions);
                standardVersions = builder.UpdatePieceWtVersionInfo(standardVersions, dataRowWithValues);
            }

            return standardVersions;
        }
        private List<StandardVersion> ProcessStandardPartEInfo(string[] row, int lineNumber,
            StandardVersionCollectionBuilder builder, List<StandardVersion> standardVersions)
        {
            if (CheckDataRowExists("PartE", lineNumber))
            {
                CsvDataRow dataRow = GetCSVRowSetting("PartE", lineNumber);
                CsvDataRow dataRowWithValues = GetCsvRowDataValue(dataRow, row);
                // then get the values and build the data model 

                // step 1 : get the no of versions
                int noOfVersions = row.Count() - 3;
                if (standardVersions == null)
                    standardVersions = builder.BuildVersionCollection(noOfVersions);
                standardVersions = builder.UpdatePartEVersionInfo(standardVersions, dataRowWithValues);
            }

            return standardVersions;
        }

        private List<StandardVersion> ProcessStandardPartDInfo(string[] row, int lineNumber,
            StandardVersionCollectionBuilder builder, List<StandardVersion> standardVersions)
        {
            if (CheckDataRowExists("PartD", lineNumber))
            {
                CsvDataRow dataRow = GetCSVRowSetting("PartD", lineNumber);
                CsvDataRow dataRowWithValues = GetCsvRowDataValue(dataRow, row);
                // then get the values and build the data model 

                // step 1 : get the no of versions
                int noOfVersions = row.Count() - 3;
                if (standardVersions == null)
                    standardVersions = builder.BuildVersionCollection(noOfVersions);
                standardVersions = builder.UpdatePartDVersionInfo(standardVersions, dataRowWithValues);
            }

            return standardVersions;
        }

        private CsvDataRow GetCsvRowDataValue(CsvDataRow dataRow, string[] row)
        {
            // remove first 3 data from array. 
            if (row.Count() > 3)
                row = row.Skip(3).ToArray();
            //convert row data to long
            List<long> copiesList = Array.ConvertAll(row,
            element => Convert.ToInt64(element)).ToList();

            dataRow.Copies = copiesList;
            return dataRow;
        }

        private VersionIdRow GetCsvVersionRowDataValue(VersionIdRow dataRow, string[] row)
        {
            // remove first 3 data from array. 
            if (row.Count() > 3)
                row = row.Skip(3).ToArray();
            //convert row data to long
            List<string> versionList = Array.ConvertAll(row,
            element => element).ToList();

            dataRow.values = versionList;
            return dataRow;
        }

        private PieceWeightRow GetCsvRowDataValue(PieceWeightRow pieceWtRow, string[] row)
        {
            // remove first 3 data from array. 
            if (row.Count() > 3)
                row = row.Skip(3).ToArray();
            //convert row data to long
            List<decimal> valuesList = Array.ConvertAll(row,
            element => Convert.ToDecimal(element)).ToList();

            pieceWtRow.values = valuesList;
            return pieceWtRow;
        }

        public static T GetEnumValueFromDescription<T>(string description)
        {
            var type = typeof(T);
            if (!type.IsEnum)
                throw new ArgumentException();
            FieldInfo[] fields = type.GetFields();
            var field = fields
                            .SelectMany(f => f.GetCustomAttributes(
                                typeof(DescriptionAttribute), false), (
                                    f, a) => new { Field = f, Att = a })
                            .Where(a => ((DescriptionAttribute)a.Att)
                                .Description == description).SingleOrDefault();
            return field == null ? default(T) : (T)field.Field.GetRawConstantValue();
        }

        private CsvDataRow GetCSVRowSetting(string partInfo, int lineNumber)
        {
            XDocument doc = System.Xml.Linq.XDocument.Load(@"..\\..\\StandardSettings.xml");
            XElement data = doc.XPathSelectElements($".//{partInfo}/Row[@LineNumber='{lineNumber}']").FirstOrDefault();
            string destinationEntry = data.Attribute("DestinationEntry").Value;
            string sortation = data.Attribute("Sortation").Value;

            DestinationEntry entry = GetEnumValueFromDescription<DestinationEntry>(destinationEntry);

            Sortation currentsortation = GetEnumValueFromDescription<Sortation>(sortation);
            return new CsvDataRow()
            {
                destinationEntry = entry,
                sortation = currentsortation
            };
        }

        private PieceWeightRow GetPieceWeightSetting(int lineNumber)
        {
            XDocument doc = System.Xml.Linq.XDocument.Load(@"..\\..\\StandardSettings.xml");
            XElement data = doc.XPathSelectElements($".//PieceWeightInfos/Row[@LineNumber='{lineNumber}']").FirstOrDefault();
            string pieceWeightHeader = data.Attribute("PieceWeightInfo").Value;

            PieceWeight pieceWtEnum = GetEnumValueFromDescription<PieceWeight>(pieceWeightHeader);
            return new PieceWeightRow()
            {
                pieceWeight = pieceWtEnum
            };

        }




        private bool CheckDataRowExists(string partInfo, int lineNumber)
        {
            bool returnValue = false;
            XDocument doc = System.Xml.Linq.XDocument.Load(@"..\\..\\StandardSettings.xml");
            XElement data = doc.XPathSelectElements($".//{partInfo}/Row[@LineNumber='{lineNumber}']").FirstOrDefault();

            if (data != null)
                returnValue = true;
            return returnValue;
        }

        private bool CheckHeaderRowExists(int lineNumber)
        {
            bool returnValue = false;
            XDocument doc = System.Xml.Linq.XDocument.Load(@"..\\..\\StandardSettings.xml");
            XElement data = doc.XPathSelectElements($".//PieceWeightInfo[@LineNumber='{lineNumber}']").FirstOrDefault();

            if (data != null)
                returnValue = true;
            return returnValue;
        }
    }
}

